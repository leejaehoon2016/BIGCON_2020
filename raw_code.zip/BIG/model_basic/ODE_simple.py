import torch.nn as nn
import torch
from torchdiffeq import odeint

class ODEFunc(nn.Module):
    def __init__(self, first_layer_dim):
        super(ODEFunc, self).__init__()
        self.layer_start = nn.Sequential(nn.BatchNorm1d(first_layer_dim),
                                    nn.ReLU())

        self.layer_t = nn.Sequential(nn.Linear(first_layer_dim + 1, first_layer_dim * 2),
                                     nn.BatchNorm1d(first_layer_dim * 2),
                                     nn.ReLU(),
                                     nn.Linear(first_layer_dim * 2, first_layer_dim * 1),
                                     nn.BatchNorm1d(first_layer_dim * 1),
                                     nn.ReLU())
        for m in self.layer_t:
            if isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, mean=0, std=0.1)
                nn.init.constant_(m.bias, val=0)

    def forward(self, t, x):
        out = self.layer_start(x)
        tt = torch.ones_like(x[:,[0]]) * t
        out = torch.cat([out,tt],dim = 1)
        out = self.layer_t(out)
        return out



class ODEBlock(nn.Module):
    def __init__(self, odefunc, device, rtol = 1e-3, atol = 1e-3):
        super(ODEBlock, self).__init__()
        self.odefunc = odefunc
        self.device = device
        self.rtol = rtol
        self.atol = atol

    def forward(self, x):
        integration_time = torch.tensor([0., 1.], requires_grad=False).to(self.device).type_as(x)
        out_ode = odeint(self.odefunc, x, integration_time, rtol=self.rtol, atol=self.atol)
        return out_ode[1]


# class ODENet(nn.Module):
#     def __init__(self, total_input_size, device, rtol, atol):
#         super(ODENet, self).__init__()
#         dim = total_input_size
#         self.layer1 = nn.Sequential(nn.Linear(dim, dim * 2),
#                                     # nn.Dropout(0.3),
#                                     nn.BatchNorm1d(dim * 2),
#                                     nn.ReLU())
#         self.res1 = ODEBlock(ODEFunc(dim * 2), device, rtol, atol)
#         self.layer2 = nn.Sequential(nn.Linear(dim * 2, dim),
#                                     nn.BatchNorm1d(dim),
#                                     nn.ReLU(),
#                                     nn.Linear(dim, 1),
#                                     nn.Tanh())
#
#     def forward(self, x):
#         x = self.layer1(x)
#         x = x + self.res1(x)
#         x = x + self.res1(x)
#         x = self.layer2(x)
#         return x

class ODENet(nn.Module):
    def __init__(self, total_input_size, device, rtol, atol):
        super(ODENet, self).__init__()
        dim = total_input_size
        # self.layer1 = nn.Sequential(nn.Linear(dim, dim * 2),
        #                             # nn.Dropout(0.3),
        #                             nn.BatchNorm1d(dim * 2),
        #                             nn.ReLU())
        self.layer1 = ODEBlock(ODEFunc(dim), device, rtol, atol)
        self.layer2 = nn.Sequential(nn.Linear(dim, dim),
                                    nn.Tanh())

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        return x
