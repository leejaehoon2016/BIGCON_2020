import torch
import torch.nn as nn

random_seed = 0
SOURCE_MAX_LENGTH = 38309
TARGET_MAX_LENGTH = 2891
enc_hidden_size = dec_hidden_size = 256
BATCH_SIZE = 32

torch.manual_seed(random_seed)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class Embedding(nn.Module):
    def __init__(self, input_size, embedding_size):
        super(Embedding, self).__init__()
        self.embedding = nn.Embedding(input_size, embedding_size)

    def forward(self, x):
        out = self.embedding(x)
        return out

class Encoder(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(Encoder, self).__init__()
        self.gru = nn.GRU(input_size, hidden_size)

    def forward(self, input, hidden):
        """(length, BATCH_SIZE, feature num)
           (num_layers * num_directions(= 1), batch, hidden_size)"""
        x, hidden = self.gru(input, hidden)
        return x, hidden

class Decoder(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(Decoder, self).__init__()
        self.gru = nn.GRU(input_size, hidden_size)
        self.out = nn.Linear(hidden_size, 1)
        # self.last = nn.tanh()

    def forward(self, x, hidden):
        """(length, BATCH_SIZE, feature num)
           (num_layers * num_directions(= 1), batch, hidden_size)"""
        x, hidden = self.gru(x, hidden)
        out = self.out(x[0]) # minmax 사용시 self.last 한번더 통과시켜야함
        return out
