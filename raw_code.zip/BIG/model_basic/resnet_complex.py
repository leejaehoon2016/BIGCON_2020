import torch.nn as nn

class ResNet(nn.Module):
    def __init__(self,total_input_size):
        super(ResNet, self).__init__()
        dim = total_input_size
        self.layer1 = nn.Sequential(nn.Linear(dim, dim * 3),
                                    nn.BatchNorm1d(dim * 3),
                                    nn.ELU())
        self.res1 = nn.Sequential(nn.Linear(dim * 3, dim * 3),
                                  nn.BatchNorm1d(dim * 3),
                                  nn.ELU())
        self.layer2 = nn.Sequential(nn.Linear(dim * 3, dim * 2),
                                    nn.BatchNorm1d(dim * 2),
                                    nn.ELU())
        self.res2 = nn.Sequential(nn.Linear(dim * 2, dim * 2),
                                  nn.BatchNorm1d(dim* 2),
                                  nn.ELU())
        self.layer3 = nn.Sequential(nn.Linear(dim * 2, dim),
                                    nn.BatchNorm1d(dim),
                                    nn.ELU())
        self.res3 = nn.Sequential(nn.Linear(dim, dim),
                                  nn.BatchNorm1d(dim),
                                  nn.ELU())
        self.last = nn.Sequential(nn.Linear(dim, 1),
                                  nn.Tanh())


    def forward(self, x):
        x = self.layer1(x)
        x = x + self.res1(x)
        x = self.layer2(x)
        x = x + self.res2(x)
        x = self.layer3(x)
        x = x + self.res3(x)
        out = self.last(x)
        return out, x