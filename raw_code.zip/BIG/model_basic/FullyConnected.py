import torch.nn as nn

class FullyConnected(nn.Module):
    def __init__(self,total_input_size):
        super(FullyConnected, self).__init__()
        dim = total_input_size
        self.layer1 = nn.Sequential(nn.Linear(dim, dim * 2),
                                    nn.BatchNorm1d(dim * 2),
                                    nn.CELU(),
                                    nn.Linear(dim * 2, dim * 2),
                                    nn.BatchNorm1d(dim * 2),
                                    nn.CELU(),
                                    nn.Linear(dim * 2, dim),
                                    nn.BatchNorm1d(dim),
                                    nn.Linear(dim, 1),
                                    nn.Tanh())

    def forward(self, x):
        out = self.layer1(x)
        return out