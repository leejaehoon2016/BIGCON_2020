from data.data_preprocessing import make_data_set,make_dataset_embedding
from util.util import test_train_index



class BaseClass:
    def __init__(self, info, max_y, embedding_set, device, concat, time_series, TEST_RATIO, BATCH_SIZE, num, drop):
        self.embedding_set = embedding_set
        self.device = device
        self.concat = concat
        data, final_json, over_y_max, self.price = make_data_set(info,max_y,device, num)
        if time_series:
            all_column_info, self.total_input_size, self.x_embedding, self.x_val, self.y_val, self.y_min, self.y_max, self.revenue, \
            self.start_date, self.date_id, self.zero_pad, self.broad_id = \
                make_dataset_embedding(data, final_json, info, embedding_set, drop, device, concat, time_series)
        else:
            all_column_info, self.total_input_size, self.x_embedding, self.x_val, self.y_val, self.y_min, self.y_max, self.revenue = \
                make_dataset_embedding(data,final_json,info,embedding_set,drop,device,concat,time_series)

        #####################
        # TEST, TRAIN SET
        #####################
        self.train_index, self.test_index = test_train_index(data, TEST_RATIO, over_y_max, time_series)
        if BATCH_SIZE == "max":
            self.BATCH_SIZE = len(self.train_index)
        else:
            self.BATCH_SIZE = BATCH_SIZE

    def fit(self, Model_Class, EPOCH, E_lr, FC_lr, E_beta, FC_beta, reg_coef, coef, random_state, save_loc, writer):
        pass
    def predict(self):
        pass

