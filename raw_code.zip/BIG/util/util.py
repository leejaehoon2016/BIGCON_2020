import torch
import numpy as np
from data.data_preprocessing import _check_set

def cal_MAPE(hat_y, y, index, revenue, price, y_max, y_min, revenue_bool):
    if revenue_bool:
        y_real = revenue[index]
    else:
        y_real = (((y + 1) / 2) * (y_max - y_min) + y_min) * price[index]
    hat_y_real = (((hat_y + 1) / 2) * (y_max - y_min) + y_min) * price[index]
    result_loss = torch.mean(torch.abs((y_real - hat_y_real)) / y_real)
    return y_real, hat_y_real, result_loss

def make_embedding(embedding_set, x_embedding, index, device, reg_coef, coef, concat):
    for name, val in x_embedding.items():
        val["model_basic"](val["data"][index].to(device)) * coef[name]

    embedded_values = [val["model_basic"](val["data"][index].to(device)) * coef[name] for name, val in x_embedding.items()]
    reg_values = [(embedded_values[i] ** 2) * reg_coef[name] for i, name in enumerate(x_embedding.keys())]
    reg_values = torch.cat(reg_values, dim=1)
    regularizer = reg_values.mean()
    if concat == True:
        embedded_value = torch.cat(embedded_values, dim=1)
    else:
        tmp = {}
        concat = []
        for i, name in enumerate(x_embedding.keys()):
            set_name = _check_set(name, embedding_set)
            if set_name == "concat":
                concat.append(embedded_values[i])
            elif set_name in tmp:
                tmp[set_name].append(embedded_values[i])
            else:
                tmp[set_name] = [embedded_values[i]]
        embedded_value = torch.cat([sum(val) / len(val) for val in tmp.values()] + concat,dim = 1)
    return embedded_value, regularizer

def write_loss1(loss, i, lst, writer, plot_name):
    lst.append(loss.item())
    writer.add_scalar(plot_name, loss, i)

def write_loss2(loss1, loss2, name1, name2, i, lst1, lst2, writer, plot_name):
    lst1.append(loss1.item()) ; lst2.append(loss2.item())
    dic = {name1 : loss1, name2:loss2}
    writer.add_scalars(plot_name, dic, i)

def test_train_index(data, test_ratio, over_y_max, time_series):
    import random
    if time_series == False:
        total_length = len(data)
        total_index = list(set(range(total_length)) - set(over_y_max))
        random.shuffle(total_index)
        test_index = total_index[: int(total_length * test_ratio)] + list(over_y_max)
        train_index = total_index[int(total_length * test_ratio):]
        return train_index, test_index
    else:
        if len(over_y_max) != 0:
            print("Warning: over_y_max 인자는 사용되지 않았습니다.")
        total_length = data['date_split'].max()
        total_day = list(range(total_length))
        random.shuffle(total_day)
        test_day = total_day[: int(total_length * test_ratio)]
        train_day = total_day[int(total_length * test_ratio):]
        return change_day_to_index(data, train_day), change_day_to_index(data, test_day), train_day, test_day

def change_day_to_index(data,day):
    if type(day) is int:
        day = [day]
    else:
        day = list(day)
    return list(data[data["date_split"].isin(day)].index)

def save_everything(spec, train_MAPE_lst, total_loss_r_lst, test_MAPE_lst, save_loc_name):
    save_loc_name = save_loc_name + "_" + str(round(min(test_MAPE_lst),5))
    with open(save_loc_name + "_spec.txt","w") as f:
        f.write(spec)
    np.save(save_loc_name + "_train.npy", np.array(train_MAPE_lst))
    np.save(save_loc_name + "_test.npy", np.array(test_MAPE_lst))
    np.save(save_loc_name + "_r.npy", np.array(total_loss_r_lst))



################
# 수정 필요함
################
def make_ML_data(drop_columns, all_column_info, x_embedding, x_val, y_val, y_min, y_max, revenue, embedding, concat, y_type):
    all_column = []
    for name in all_column_info:
        if name not in drop_columns:
            all_column += all_column_info[name]
    all_embedding = []
    for name in x_embedding:
        if name not in drop_columns:
            if embedding == True:
                all_embedding.append(x_embedding[name]["model_basic"](x_embedding[name]["data"]))
            else:
                all_embedding.append(x_embedding[name]["data"])
    if concat == False and embedding == True:
        x_val = torch.cat([x_val[:, all_column], sum(all_embedding)], dim=1)
    else:
        x_val = torch.cat([x_val[:,all_column], torch.cat(all_embedding,dim = 1)],dim = 1)

    if y_type == "revenue":
        y_val = revenue
    elif y_type == "real_y":
        y_val = (((y_val + 1) / 2) * (y_max - y_min) + y_min)
    elif y_type == "norm_y":
        y_val = y_val
    else:
        raise Exception("revenue, real_y, norm_y 중에 선택")
    return np.array(x_val), np.array(y_val.cpu())

def FC_embedding_model_save(fc, x_embedding, test_MAPE, all_MAPE):
    if test_MAPE == min(all_MAPE):
        for name in x_embedding:
            torch.save(x_embedding[name]["model_basic"].state_dict(),"tmp_model_save/{}.pth".format(name))
        torch.save(fc.state_dict(),"tmp_model_save/fc.pth")

def FC_embedding_model_load(fc, x_embedding,device):
        for name in x_embedding:
            x_embedding[name]["model_basic"].load_state_dict(torch.load("tmp_model_save/{}.pth".format(name), map_location=device))
        fc.load_state_dict(torch.load("tmp_model_save/fc.pth", map_location=device))


##############
# 예전에 쓴것
##############
def model_load_embedding(names, x_embedding, device):
    for name in names:
        x_embedding[name]["model_basic"].load_state_dict(torch.load("tmp_model_save/{}.pth".format(name), map_location = device))

def model_save_embedding(name, x_embedding, test_MAPE, all_MAPE):
    if test_MAPE == min(all_MAPE):
        torch.save(x_embedding[name]["model_basic"].state_dict(),"tmp_model_save/{}.pth".format(name))

def model_load_embedding2(names, x_embedding, device):
    for name in names:
        x_embedding[name]["model_basic"].load_state_dict(torch.load("tmp_model_save/{}_2.pth".format(name), map_location = device))

def model_save_embedding2(name, x_embedding, test_MAPE, all_MAPE):
    if test_MAPE == min(all_MAPE):
        torch.save(x_embedding[name]["model_basic"].state_dict(),"tmp_model_save/{}_2.pth".format(name))

def clipping_all_time(all_time, clamp_even):
    if clamp_even:
        total_num = len(all_time)
        with torch.no_grad():
            for j in range(total_num):
                if j == 0:
                    start = 0 + 0.00001
                else:
                    start = 1 / total_num * j + 0.00001

                if j == len(all_time) - 1:
                    end = 1 - 0.00001
                else:
                    end = 1 / total_num * (j + 1) - 0.00001
                all_time[j] = all_time[j].clamp_(min=start, max=end)
    else:
        with torch.no_grad():
            for j in range(len(all_time)):
                if j == 0:
                    start = 0 + 0.00001
                else:
                    start = all_time[j - 1].item() + 0.00001

                if j == len(all_time) - 1:
                    end = 1 - 0.00001
                elif all_time[j + 1].item() - 0.00001 <= 0:
                    end = start + 0.00001
                else:
                    end = all_time[j + 1].item() - 0.00001
                all_time[j] = all_time[j].clamp_(min=start, max=end)

def ODETime(num_split, device):
    return [torch.tensor([1 / num_split * i], dtype=torch.float32, requires_grad=True, device=device) for
            i in range(1, num_split)]

def save_list(save_loc, MAPE_lst, test_hat_y_real_lst, test_y_real_lst, total_loss_lst):
    vals = [MAPE_lst, test_hat_y_real_lst, test_y_real_lst, total_loss_lst]
    names = ["MAPE_lst", "test_hat_y_real_lst", "test_y_real_lst", "total_loss_lst"]
    for name, val in zip(names,vals):
        np.save(save_loc +"/" + name + "_" +str(round(min(MAPE_lst), 5)) + ".npy", val)