import torch
import torch.optim as optim
from util._0_base_class import BaseClass
from util.util import make_embedding, cal_MAPE, write_loss1, write_loss2
import random

class FCClass(BaseClass):
    def fit(self, Model_Class, EPOCH, E_lr, FC_lr, E_beta, FC_beta, E_weight_decay, FC_weight_decay,
            reg_coef, coef, random_state, writer, save_file):
        ########################
        # Model and Optimizer
        ########################
        self.net = Model_Class(self.total_input_size).to(self.device)
        E_param = []
        for val in self.x_embedding.values():
            E_param += list(val["model_basic"].parameters())
        optimizerE = optim.Adam(E_param, lr=E_lr, betas=E_beta, weight_decay=E_weight_decay)
        optimizerFC = optim.Adam(self.net.parameters(), lr=FC_lr, betas=FC_beta, weight_decay= FC_weight_decay)

        total_iter = 0
        train_MAPE_lst = []
        total_loss_r_lst = []
        test_MAPE_lst = []
        test_hat_y_real_lst = []
        test_y_real_lst = []
        for i in range(EPOCH):
            random.shuffle(self.train_index)
            for j in range(len(self.train_index) // self.BATCH_SIZE):
                ###################
                # Train
                ###################
                self.net.train();
                total_iter += 1
                index = self.train_index[j * self.BATCH_SIZE: (j + 1) * self.BATCH_SIZE]
                embedded_value, regularizer = make_embedding(self.embedding_set,self.x_embedding, index, self.device, reg_coef, coef, concat=self.concat)
                if len(self.x_val) == 0:
                    x, y = embedded_value.to(self.device), self.y_val[index].to(self.device)
                else:
                    x, y = torch.cat([self.x_val[index].to(self.device), embedded_value], axis=1).to(self.device), self.y_val[index].to(self.device)
                hat_y = self.net(x)[0].to(self.device)
                _, _, FC_loss = cal_MAPE(hat_y, y, index, self.revenue, self.price, self.y_max, self.y_min, revenue_bool=True)
                write_loss1(FC_loss, i, train_MAPE_lst, writer, "loss/train_MAPE")
                write_loss1(regularizer, i, total_loss_r_lst, writer, "loss/regularizer")
                total_loss = FC_loss + regularizer
                optimizerE.zero_grad()
                optimizerFC.zero_grad()
                total_loss.backward()
                optimizerE.step()
                optimizerFC.step()

                ################
                # TEST
                ################
                self.net.eval()
                test_embedded_value, _ = make_embedding(self.embedding_set,self.x_embedding, self.test_index, self.device, reg_coef, coef, concat=self.concat)
                if len(self.x_val) == 0:
                    test_x, test_y = test_embedded_value.to(self.device), self.y_val[self.test_index].to(self.device)
                else:
                    test_x, test_y = torch.cat([self.x_val[self.test_index].to(self.device), test_embedded_value],axis=1).to(self.device), \
                                     self.y_val[self.test_index].to(self.device)


                test_hat_y = self.net(test_x)[0].to(self.device)
                test_y_real, test_hat_y_real, MAPE = cal_MAPE(test_hat_y, test_y, self.test_index, self.revenue, self.price, self.y_max,
                                                              self.y_min, revenue_bool=True)
                write_loss1(MAPE, i, test_MAPE_lst, writer, "loss/test_MAPE")
                write_loss2(test_hat_y_real.mean(), test_y_real.mean(), "test_hat_y_real", "test_y_real", i,
                            test_hat_y_real_lst, test_y_real_lst, writer, "loss/real_price")
            if i % 100 == 99:
                save_file.write("{} epoch: {}, {}".format(i, round(min(test_MAPE_lst), 5), round(min(train_MAPE_lst), 5))  + "\n")
                print("{} epoch:".format(i), round(min(test_MAPE_lst), 5), round(min(train_MAPE_lst), 5))



    def predict(self, reg_coef, coef):
        test_embedded_value, _ = make_embedding(self.embedding_set, self.x_embedding, self.test_index, self.device,
                                                reg_coef, coef, concat=self.concat)
        test_x, test_y = torch.cat([self.x_val[self.test_index].to(self.device), test_embedded_value], axis=1).to(
            self.device), \
                         self.y_val[self.test_index].to(self.device)
        test_hat_y = self.net(test_x)[0].to(self.device)
        _, test_hat_y_real,_ = cal_MAPE(test_hat_y, test_y, self.test_index, self.revenue, self.price, self.y_max, self.y_min, revenue_bool=True)
        return test_hat_y_real


