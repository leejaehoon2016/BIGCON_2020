# BEST 0.3081  E_lr, FC_lr = 5e-4, 5e-4 {"상품군" : 0.0001, "마더코드" : 0.001, "브랜드" : 0.001, "상품코드": 0.01, "월" :0.001, "시간":0.001, "방송요일":0.0001}
# E,FC weight_decay=0.01

from model_basic.resnet_complex import ResNet
GPU_NUM = 0 # 원하는 GPU 번호 입력
concat = True; time_series = False; max_y= 10000000000000000000000000000000
TEST_RATIO = 0.10
EPOCH = 100000
BATCH_SIZE = 10000
E_lr, FC_lr = 5e-4, 5e-4
E_beta, FC_beta = (0.5,0.9), (0.5,0.9)
reg_coef = {"상품군" : 0.0001, "마더코드" : 0.001, "브랜드" : 0.001, "상품코드": 0.01, "월" :0.001, "시간":0.001, "방송요일":0.0001}
coef = {"상품군" : 0.0001, "마더코드" : 0.001, "브랜드" : 0.001, "상품코드": 0.01, "월" :0.001, "시간":0.001, "방송요일":0.0001}
random_state = 777
# data_loc = "data/raw_data/preprocessed_feature"
save_loc = "/home/ljh5694/tmp/result/result_res"

####################
# import
####################
import torch
import torch.optim as optim
import warnings, os, random, json
import pandas as pd
from util.util import cal_MAPE, write_loss1, write_loss2, make_embedding, make_dataset_embedding, test_train_index
from torch.utils.tensorboard import SummaryWriter
writer = SummaryWriter()
warnings.filterwarnings(action='ignore')
device = torch.device(f'cuda:{GPU_NUM}' if torch.cuda.is_available() else 'cpu')
torch.cuda.set_device(device) # change allocation of current GPU
print ('Current cuda device ', torch.cuda.current_device()) # check
random.seed(random_state)
torch.manual_seed(random_state)
torch.cuda.manual_seed_all(random_state)

data = pd.read_csv(data_loc + ".csv",index_col = 0).reset_index(drop=True)
with open(data_loc + ".json", "r") as json_file:
    meta_data = json.load(json_file)

if not(os.path.isdir(save_loc)):
    os.makedirs(save_loc)

all_column_info, total_input_size, x_embedding, x_val, y_val, y_min, y_max, revenue, price, over_y_max = \
    make_dataset_embedding(data, meta_data, ["None", "노출(분)_all", '월별소비액'],device, concat = concat, time_series = time_series, max_y = max_y)

#####################
# TEST, TRAIN SET
#####################
train_index, test_index = test_train_index(data, TEST_RATIO, [], time_series)
if BATCH_SIZE == "max":
    BATCH_SIZE = len(train_index)

########################
# Model and Optimizer
########################
net = ResNet(total_input_size).to(device)
# net = ODENet(total_input_size, device, rtol = 1e-3, atol = 1e-3).to(device)

E_param = []
for val in x_embedding.values():
    E_param += list(val["model_basic"].parameters())
optimizerE = optim.Adam(E_param, lr = E_lr, betas = E_beta, weight_decay=0.01)
optimizerFC = optim.Adam(net.parameters(), lr = FC_lr, betas = FC_beta, weight_decay=0.01)


total_iter = 0
train_MAPE_lst = []
total_loss_r_lst = []
test_MAPE_lst = []
test_hat_y_real_lst = []
test_y_real_lst = []
for i in range(EPOCH):
    random.shuffle(train_index)
    for j in range(len(train_index) // BATCH_SIZE):
        ###################
        # Train
        ###################
        net.train() ; total_iter += 1
        index = train_index[j * BATCH_SIZE: (j+1) * BATCH_SIZE]
        embedded_value, regularizer = make_embedding(x_embedding, index, device, reg_coef,concat = concat)
        x, y = torch.cat([x_val[index].to(device), embedded_value], axis =1).to(device), y_val[index].to(device)
        hat_y = net(x)[0].to(device)
        _, _, FC_loss = cal_MAPE(hat_y, y, index, revenue, price, y_max, y_min, revenue_bool = False)
        write_loss1(FC_loss, i, train_MAPE_lst, writer, "loss/train_MAPE")
        write_loss1(regularizer, i, total_loss_r_lst, writer, "loss/regularizer")


        total_loss = FC_loss + regularizer
        optimizerE.zero_grad()
        optimizerFC.zero_grad()
        total_loss.backward()
        optimizerE.step()
        optimizerFC.step()

        ################
        # TEST
        ################
        net.eval()
        test_embedded_value, _ = make_embedding(x_embedding, test_index, device, reg_coef, concat = concat)
        test_x, test_y = torch.cat([x_val[test_index].to(device), test_embedded_value],axis =1).to(device), y_val[test_index].to(device)
        test_hat_y = net(test_x)[0].to(device)

        MAPE = torch.mean(torch.abs(test_y - test_hat_y) / test_y)
        test_y_real, test_hat_y_real, MAPE = cal_MAPE(test_hat_y, test_y, test_index, revenue, price, y_max, y_min, revenue_bool = True)
        write_loss1(MAPE, i, test_MAPE_lst, writer, "loss/test_MAPE")
        write_loss2(test_hat_y_real.mean(), test_y_real.mean(), "test_hat_y_real", "test_y_real", i,
                    test_hat_y_real_lst, test_y_real_lst, writer, "loss/real_price")

    if i % 100 == 99:
        print("{} epoch:".format(i), round(min(test_MAPE_lst),5), round(min(train_MAPE_lst),5))
