from model_basic.resnet import ResNet
from model_time.GRU import GRUNet
GPU_NUM = 3 # 원하는 GPU 번호 입력
concat = True ; time_series = True
TEST_RATIO = 0.15
BASE_EPOCH, TIME_EPOCH = 0, 10000
BASE_BATCH_SIZE, TIME_BATCH_SIZE = 30000, "필요없음"
E_lr, BaseNet_lr, TimeNet_lr = 1e-3, 1e-3, 1e-3
E_beta, BaseNet_beta, TimeNet_beta = (0.5,0.9), (0.5,0.9), (0.5,0.9)
reg_coef = {"상품군" : 0.0001, "마더코드" : 0.001, "브랜드" : 0.01, "상품코드": 0.01}
random_state = 0
data_loc = "data/preprocessed_feature"
save_loc = "/home/ljh5694/tmp/result/result_res"

####################
# import
####################
import torch
import torch.optim as optim
import warnings, os, random, json
import pandas as pd
from util.util import cal_MAPE, write_loss1, write_loss2, make_embedding, make_dataset_embedding, \
    test_train_index, FC_embedding_model_save, FC_embedding_model_load, change_day_to_index
from torch.utils.tensorboard import SummaryWriter
writer = SummaryWriter()
warnings.filterwarnings(action='ignore')
device = torch.device(f'cuda:{GPU_NUM}' if torch.cuda.is_available() else 'cpu')
torch.cuda.set_device(device) # change allocation of current GPU
print ('Current cuda device ', torch.cuda.current_device()) # check
random.seed(random_state)
torch.manual_seed(random_state)
torch.cuda.manual_seed_all(random_state)

data = pd.read_csv(data_loc + ".csv",index_col = 0).reset_index(drop=True)
with open(data_loc + ".json", "r") as json_file:
    meta_data = json.load(json_file)

if not(os.path.isdir(save_loc)):
    os.makedirs(save_loc)

all_column_info, total_input_size, x_embedding, x_val, y_val, y_min, y_max, revenue, price, start_date, date_id, zero_pad, broad_id = \
    make_dataset_embedding(data, meta_data, ["None", "노출(분)_all", '월별소비액'],device, concat = concat, time_series = time_series)


#####################
# TEST, TRAIN SET
#####################
train_index, test_index = test_train_index(data, TEST_RATIO, False)


################################################
# Model BaseNet Train
################################################

########################
# Model and Optimizer
########################
BaseNet = ResNet(total_input_size).to(device)
E_param = []
for val in x_embedding.values():
    E_param += list(val["model_basic"].parameters())
optimizerE = optim.Adam(E_param, lr = E_lr, betas = E_beta)
optimizerBaseNet = optim.Adam(BaseNet.parameters(), lr = BaseNet_lr, betas = BaseNet_beta)


total_iter = 0
train_MAPE_lst = []
total_loss_r_lst = []
test_MAPE_lst = []
test_hat_y_real_lst = []
test_y_real_lst = []
for i in range(BASE_EPOCH):
    random.shuffle(train_index)
    for j in range(len(train_index) // BASE_BATCH_SIZE):
        ###################
        # Train
        ###################
        BaseNet.train() ; total_iter += 1
        index = train_index[j * BASE_BATCH_SIZE: (j+1) * BASE_BATCH_SIZE]
        embedded_value, regularizer = make_embedding(x_embedding, index, device, reg_coef,concat = concat)
        x, y = torch.cat([x_val[index].to(device), embedded_value],axis =1).to(device), y_val[index].to(device)
        hat_y = BaseNet(x)[0].to(device)

        _,_,FC_loss = cal_MAPE(hat_y, y, index, revenue, price, y_max, y_min, revenue_bool = True)
        write_loss1(FC_loss, i, train_MAPE_lst, writer, "loss/train_MAPE")
        write_loss1(regularizer, i, total_loss_r_lst, writer, "loss/regularizer")


        total_loss = FC_loss + regularizer
        optimizerE.zero_grad()
        optimizerBaseNet.zero_grad()
        total_loss.backward()
        optimizerE.step()
        optimizerBaseNet.step()

        ################
        # TEST
        ################
        BaseNet.eval()
        test_embedded_value, _ = make_embedding(x_embedding, test_index, device, reg_coef, concat = concat)
        test_x, test_y = torch.cat([x_val[test_index].to(device), test_embedded_value],axis =1).to(device), y_val[test_index].to(device)
        test_hat_y = BaseNet(test_x)[0].to(device)

        test_y_real, test_hat_y_real, MAPE = cal_MAPE(test_hat_y, test_y, test_index, revenue, price, y_max, y_min, revenue_bool = True)
        write_loss1(MAPE, i, test_MAPE_lst, writer, "loss/test_MAPE")
        write_loss2(test_hat_y_real.mean(), test_y_real.mean(), "test_hat_y_real", "test_y_real", i,
                    test_hat_y_real_lst, test_y_real_lst, writer, "loss/real_price")
        FC_embedding_model_save(BaseNet, x_embedding, MAPE,test_MAPE_lst)

    if i % 100 == 99:
        print("{} epoch:".format(i), round(min(test_MAPE_lst),5))


################################################
# Model TimeNet Train
################################################

########################
# Model and Optimizer
########################
# BaseNet = ResNet(total_input_size).to(device)
# FC_embedding_model_load(BaseNet,x_embedding,device)
# BaseNet.eval()
data = data[data["판매량"] < 1000].reset_index(drop=True)
_, _, train_day, test_day = test_train_index(data, TEST_RATIO, time_series)
TimeNet = GRUNet(total_input_size,device).to(device)

E_param = []
for val in x_embedding.values():
    E_param += list(val["model_basic"].parameters())
optimizerE = optim.Adam(E_param, lr = E_lr, betas = E_beta)
optimizerTimeNet = optim.Adam(TimeNet.parameters(), lr = TimeNet_lr, betas = TimeNet_beta, weight_decay=0.1)


total_iter = 0
train_MAPE_lst = []
total_loss_r_lst = []
test_MAPE_lst = []
test_hat_y_real_lst = []
test_y_real_lst = []
for i in range(TIME_EPOCH):
    random.shuffle(train_day)
    total_loss = 0
    for day in train_day:
        ###################
        # Train
        ###################
        TimeNet.train(); total_iter += 1
        index = change_day_to_index(data, day)
        embedded_value, regularizer = make_embedding(x_embedding, index, device, reg_coef,concat = concat)
        x, y = torch.cat([x_val[index].to(device), embedded_value],axis =1).to(device), y_val[index].to(device)
        hat_y = TimeNet(x, zero_pad[index], broad_id[index]).to(device)
        _,_,FC_loss = cal_MAPE(hat_y, y, index, revenue, price, y_max, y_min, revenue_bool = True)
        # FC_loss = torch.abs(hat_y - y).mean()
        # FC_loss = torch.nn.functional.mse_loss(hat_y, y)
        write_loss1(FC_loss, i, train_MAPE_lst, writer, "loss_time/train_MAPE")
        write_loss1(regularizer, i, total_loss_r_lst, writer, "loss_time/regularizer")
        total_loss += (FC_loss + regularizer)
    total_loss = total_loss / len(train_day)
    print(total_loss)
    optimizerE.zero_grad()
    optimizerTimeNet.zero_grad()
    with torch.autograd.set_detect_anomaly(True):
        total_loss.backward()
    optimizerTimeNet.step()
    optimizerE.step()

    ################
    # TEST
    ################
    TimeNet.eval()
    tmp_result = []
    for t_day in test_day:
        test_index = change_day_to_index(data, t_day)
        test_embedded_value, _ = make_embedding(x_embedding, test_index, device, reg_coef, concat = concat)
        test_x, test_y = torch.cat([x_val[test_index].to(device), test_embedded_value],axis =1).to(device), y_val[test_index].to(device)
        test_hat_y = TimeNet(test_x, zero_pad[test_index], broad_id[test_index]).to(device)
        tmp_result.append(test_hat_y)
    test_index = change_day_to_index(data, test_day)
    test_hat_y = torch.cat(tmp_result, dim=0)
    test_y_real, test_hat_y_real, MAPE = cal_MAPE(test_hat_y, y_val[test_index].to(device), test_index, revenue, price, y_max, y_min, revenue_bool = True)
    write_loss1(MAPE, i, test_MAPE_lst, writer, "loss_time/test_MAPE")
    write_loss2(test_hat_y_real.mean(), test_y_real.mean(), "test_hat_y_real", "test_y_real", i,
                test_hat_y_real_lst, test_y_real_lst, writer, "loss_time/real_price")
    if MAPE == min(test_MAPE_lst):
        torch.save(TimeNet.state_dict(), "tmp_model_save/time.pth")
    print("test_MAPE_lst: ",test_MAPE_lst)
    if i % 10 == 9:
        print("{} epoch:".format(i), round(min(test_MAPE_lst),5))