import xgboost as xgb
GPU_NUM = 0 # 원하는 GPU 번호 입력
concat = True ; time_series = False
TEST_RATIO = 0.20
# reg_coef = {"상품군" : 0.0001, "마더코드" : 0.001, "브랜드" : 0.001, "상품코드": 0.01}
random_state = 777
data_loc = "data/preprocessed_feature"
save_loc = "/home/ljh5694/tmp/result/result_res"

####################
# import
####################
import torch
import torch.optim as optim
import warnings, os, random, json
import numpy as np
import pandas as pd
from util.util import cal_MAPE, write_loss1, write_loss2, make_embedding, make_dataset_embedding, test_train_index, make_ML_data
from torch.utils.tensorboard import SummaryWriter
from itertools import combinations

writer = SummaryWriter()
warnings.filterwarnings(action='ignore')
device = torch.device(f'cuda:{GPU_NUM}' if torch.cuda.is_available() else 'cpu')
torch.cuda.set_device(device) # change allocation of current GPU
print ('Current cuda device ', torch.cuda.current_device()) # check
random.seed(random_state)
torch.manual_seed(random_state)
torch.cuda.manual_seed_all(random_state)

data = pd.read_csv(data_loc + ".csv",index_col = 0).reset_index(drop=True)
with open(data_loc + ".json", "r") as json_file:
    meta_data = json.load(json_file)

if not(os.path.isdir(save_loc)):
    os.makedirs(save_loc)

all_column_info, total_input_size, x_embedding, x_val, y_val, y_min, y_max, revenue, price = \
    make_dataset_embedding(data, meta_data, ["None"], device, concat = concat, time_series = time_series)

haveTo = {"상품군", "Seq 방송 개수", "일시불|무이자", "판매단가", "동시방송 상품개수"}
# mustDrop = {"마더코드", "브랜드", "상품코드"}
mustDrop = set()
drop_cand = (set(all_column_info.keys()) | set(x_embedding.keys())) - haveTo - mustDrop
print(drop_cand)
train_index, test_index = test_train_index(data, TEST_RATIO, time_series)
total_dic = {}
param =  {'colsample_bytree': 0.7744067519636624,
          'eta': 0.14588597961075972,
          'max_depth': 7,
          # 'max_leaf_nodes': 4.634649548990691,
          'min_child_weight': 1.8473095986778094,
          'subsample': 0.8229470565333281}

for i in range(len(drop_cand) + 1):
    for drop in combinations(drop_cand,i):
        drop = list(drop) + list(mustDrop)
        x, y = make_ML_data(drop, all_column_info, x_embedding, x_val, y_val, y_min, y_max, revenue,
                                    embedding= False, concat= True, y_type = "revenue")
        train_x, train_y = x[train_index], y[train_index]
        test_x, test_y = x[test_index], y[test_index]
        dtrain = xgb.DMatrix(train_x, label=train_y)
        dtest = xgb.DMatrix(test_x)
        model2 = xgb.train(param, dtrain, num_boost_round=250)
        pred = model2.predict(dtest)[:,np.newaxis]
        MAPE = np.mean(np.abs((test_y - pred) / test_y))

        # test_y_real, test_hat_y_real, MAPE = cal_MAPE(torch.tensor(pred).to(device), torch.tensor(test_y).to(device), test_index,
        #                                               revenue, price, y_max, y_min, revenue_bool=True)
        total_dic[",".join(drop)] = MAPE.item()
        print(",".join(drop), MAPE.item())
with open("data/xg_result.json", 'w', encoding='utf-8') as new_file:
    json.dump(total_dic,new_file, indent='\t')











