############
# Model
############
from util._1_FC_based_class import FCClass
from model_basic.resnet import ResNet
E_lr, FC_lr = 5e-4, 5e-4
E_beta, FC_beta = (0.5,0.9), (0.5,0.9)
E_weight_decay, FC_weight_decay = 0.01, 0.01

#################
# Data
#################

# ("category_embedding", embedding_size, min_freq(포함x)) ("category_onehot", min_freq(포함x))
# ("numerical_minmax",) ("numerical", ) ("numerical_embedding", embedding_size)
info = \
{"월": ("category_embedding",20,0), "시간": ("category_embedding",20,0), "방송요일": ("category_embedding",20,0),
 "연속 휴일": ("numerical_minmax",), "노출(분)_all": ("numerical_minmax",), "상품군": ("category_embedding",10,4),
 "마더코드": ("category_embedding",20,2), "브랜드": ("category_embedding",20,2), "상품코드": ("category_embedding",30,2),
 "판매단가": ("numerical_minmax",), "월별소비액": ("numerical",), "광고 사람": ("category_onehot", 0),
 "국내생산": ("category_onehot", 0), "기온": ("numerical_minmax",), "강수량": ("numerical_minmax",),
 "vs":  ("numerical_minmax",), "lcsch": ("numerical_minmax",), "dc10tca": ("numerical_minmax",),
 "icsr": ("numerical_minmax",), "ss": ("numerical_minmax",), "pa": ("numerical_minmax",),
 "pv": ("numerical_minmax",), "hm": ("numerical_minmax",), "ws": ("numerical_minmax",),
 "morning_drama": ("category_onehot", 0), "popular_program": ("category_onehot", 0), "동시방송 상품개수": ("numerical_minmax",),
 "Seq 방송 개수": ("numerical_minmax",), "성별": ("category_onehot", 0), "일시불/무이자": ("category_onehot", 0),
 "판매량": ("numerical_minmax",), "취급액": ("numerical",), "start_date": ("",),
 "date_split": ("",), "zero_pad": ("",), "방송_id": ("",)}
embedding_set = {"상품종류": ["상품군", "마더코드", "브랜드", "상품코드"], "시간": ["월", "시간", "방송요일"]}
reg_coef = {"상품군" : 0.0001, "마더코드" : 0.001, "브랜드" : 0.001, "상품코드": 0.01, "월" :0.001, "시간":0.001, "방송요일":0.0001}
coef = {"상품군" : 1, "마더코드" : 1, "브랜드" : 1, "상품코드": 1, "월" : 1, "시간": 1, "방송요일": 1}
concat = True


# Fix
GPU_NUM = 0 # 원하는 GPU 번호 입력
random_state = 777
save_loc = "/home/ljh5694/tmp/result/data/embed_size"
time_series = False; max_y = 10000
TEST_RATIO = 0.10
EPOCH = 3000
BATCH_SIZE = 10000
spec = str(dict(info = info))

####################
# import
####################
import torch
import warnings, random, os
from torch.utils.tensorboard import SummaryWriter
writer = SummaryWriter()
warnings.filterwarnings(action='ignore')
device = torch.device(f'cuda:{GPU_NUM}' if torch.cuda.is_available() else 'cpu')
torch.cuda.set_device(device) # change allocation of current GPU
print ('Current cuda device ', torch.cuda.current_device()) # check
random.seed(random_state); torch.manual_seed(random_state); torch.cuda.manual_seed_all(random_state)
if not(os.path.isdir(save_loc)):
    os.makedirs(save_loc)


model = FCClass(info, max_y,embedding_set,device,concat,time_series,TEST_RATIO,BATCH_SIZE, drop = ["None", "노출(분)_all", '월별소비액'])
model.fit(ResNet, EPOCH, E_lr, FC_lr, E_beta, FC_beta,E_weight_decay, FC_weight_decay,reg_coef,coef,random_state,writer,spec =spec, save_loc_name="1")