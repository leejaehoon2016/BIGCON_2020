from util.util import make_dataset_embedding_concat, make_embedding_concat
from model_basic.ODE import ODENet
GPU_NUM = 3 # 원하는 GPU 번호 입력
TEST_RATIO = 0.15
EPOCH = 1600
BATCH_SIZE = 10000
E_lr, FC_lr = 1e-2, 1e-2
E_beta, FC_beta = (0.5,0.9), (0.5,0.9)
reg_coef = {"상품군" : 0.0001, "마더코드" : 0.001, "브랜드" : 0.01, "상품코드": 0.01}
random_state = 777
data_loc = "data/preprocessed_feature"
save_loc = "/home/ljh5694/tmp/result/result_res"
num_split = 3
rtol, atol = 1e-3, 1e-3
clamp_even = False

####################
# import
####################
import torch
import torch.optim as optim
import warnings, os, random, json
import pandas as pd
from util.util import *
from torch.utils.tensorboard import SummaryWriter
writer = SummaryWriter()
warnings.filterwarnings(action='ignore')
device = torch.device(f'cuda:{GPU_NUM}' if torch.cuda.is_available() else 'cpu')
torch.cuda.set_device(device) # change allocation of current GPU
print ('Current cuda device ', torch.cuda.current_device()) # check
random.seed(random_state)
torch.manual_seed(random_state)
torch.cuda.manual_seed_all(random_state)

data = pd.read_csv(data_loc + ".csv",index_col = 0)
with open(data_loc + ".json", "r") as json_file:
    meta_data = json.load(json_file)

if not(os.path.isdir(save_loc)):
    os.makedirs(save_loc)

total_input_size, x_embedding, x_val, y_val, y_min, y_max, revenue, price = \
    make_dataset_embedding_concat(data, meta_data, ["None", "노출(분)_all", '월별소비액'],device)


#####################
# TEST, TRAIN SET
#####################
total_length = len(data)
total_index = list(range(len(data)))
random.shuffle(total_index)

test_index = total_index[: int(total_length * TEST_RATIO)]
train_index = total_index[int(total_length * TEST_RATIO):]


########################
# Model and Optimizer
########################
all_time = ODETime(num_split,device)
net = ODENet(total_input_size,num_split, device, rtol, atol).to(device)
E_param = []
for val in x_embedding.values():
    E_param += list(val["model_basic"].parameters())
optimizerE = optim.Adam(E_param, lr = E_lr, betas = E_beta)
optimizerFC = optim.Adam(list(net.parameters()) + all_time, lr = FC_lr, betas = FC_beta)


total_iter = 0
train_MAPE_lst = []
total_loss_r_lst = []
test_MAPE_lst = []
test_hat_y_real_lst = []
test_y_real_lst = []
for i in range(EPOCH):
    random.shuffle(train_index)
    for j in range(len(train_index) // BATCH_SIZE):
        ###################
        # Train
        ###################
        net.train() ; total_iter += 1
        index = train_index[j * BATCH_SIZE: (j+1) * BATCH_SIZE]
        embedded_value, regularizer = make_embedding_concat(x_embedding, index, device)
        x, y = torch.cat([x_val[index].to(device), embedded_value],axis =1).to(device), y_val[index].to(device)
        hat_y = net([x,all_time]).to(device)

        _,_,FC_loss = cal_MAPE(hat_y, y, index, revenue, price, y_max, y_min, revenue_bool = True)
        write_loss1(FC_loss, i, train_MAPE_lst, writer, "loss/train_MAPE")
        write_loss1(regularizer, i, total_loss_r_lst, writer, "loss/regularizer")

        total_loss = FC_loss + regularizer
        optimizerE.zero_grad()
        optimizerFC.zero_grad()
        total_loss.backward()
        optimizerE.step()
        optimizerFC.step()
        times = {'t' + str(t + 1): time.item() for t, time in enumerate(all_time)}
        writer.add_scalars('loss/time_points', times, i)
        clipping_all_time(all_time, clamp_even)

        ################
        # TEST
        ################
        net.eval()
        test_embedded_value, _ = make_embedding_concat(x_embedding, test_index, device)
        test_x, test_y = torch.cat([x_val[test_index].to(device), test_embedded_value],axis =1).to(device), y_val[test_index].to(device)
        test_hat_y = net([test_x,all_time]).to(device)

        test_y_real, test_hat_y_real, MAPE = cal_MAPE(test_hat_y, test_y, test_index,revenue, price, y_max, y_min, revenue_bool = True)
        write_loss1(MAPE, i, test_MAPE_lst, writer, "loss/test_MAPE")
        write_loss2(test_hat_y_real.mean(), test_y_real.mean(), "test_hat_y_real", "test_y_real", i,
                    test_hat_y_real_lst, test_y_real_lst, writer, "loss/real_price")

    if i % 100 == 99:
        print("{} epoch:".format(i), round(min(test_MAPE_lst),5))