#############
# IMPORT
#############
import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

def make_data_set(info, max_y, device, num):
    data = pd.read_csv("data/origin_data/total_feature_{}.csv".format(num), index_col=0)
    final_json = []
    price = torch.Tensor(data["판매단가"]).view(-1, 1).to(device)
    for name in info:
        if info[name][0] == "":
            continue
        elif info[name][0] == "numerical":
            data[name] = data[name].astype(float)
            final_json.append({"name": name, "type": "numerical"})

        elif info[name][0] == "numerical_minmax":
            data[name] = data[name].astype(float)
            min, max = data[name].min(), data[name].max()
            if name == "판매량":
                over_y_max = list((data.index[data[name] > max_y]))
                max = np.min(np.array([max_y,max]))
            data[name] = (data[name] - min) / (max - min)
            data[name] = 2 * data[name] - 1
            final_json.append({"name" : name, "info" : {"min": min, "max": max}, "type" : "numerical_minmax"})

        elif info[name][0] == "numerical_embedding":
            data[name] = data[name].astype(float)
            mean, std = data[name].mean(), data[name].std()
            data[name] = (data[name] - mean) / std
            final_json.append({"name": name, "embedding_size" : info[name][1], "type": "numerical_embedding"})

        elif info[name][0] == "category_onehot":
            data[name] = data[name].astype(str)
            tmp = data[name].value_counts()
            all_category = list(set(tmp.index[tmp > info[name][1]]) - {"nan"})
            dic = dict(zip(all_category, range(1, len(all_category) + 1)))
            data[name] = data[name].map(dic).fillna(0).astype(int)
            if 0 not in data[name].unique():
                data[name] = data[name] - 1
            final_json.append({"name": name, "item": sorted(list(data[name].unique())), "type": "category_onehot"})

        elif info[name][0] == "category_embedding":
            data[name] = data[name].astype(str)
            tmp = data[name].astype(str).value_counts()
            all_category = list(set(tmp.index[tmp > info[name][2]]) - {"nan"})
            dic = dict(zip(all_category, range(1, len(all_category) + 1)))
            data[name] = data[name].map(dic).fillna(0).astype(int)
            final_json.append({"name": name, "item": sorted(list(range(data[name].max() + 1))), "type": "category_embedding",
                               "embedding_size" : info[name][1]})
        else:
            raise Exception('type을 잘못 입력했습니다. "category_embedding", "category_onehot", "numerical_minmax", '
                            '"numerical_embedding", "numerical", ""중 하나를 입력해야합니다.')
    return data, final_json, over_y_max, price

def make_dataset_embedding(data, meta_data, info, embedding_set, drop, device, concat, time_series):
    _check_category_set(info, embedding_set, concat)
    total_input_size = 0
    x_val_pos = 0
    x_embedding = {}
    x_val = []
    y_val = None
    y_min, y_max = None, None
    revenue = None
    check = dict(zip(list(embedding_set.keys()) + ["concat"], [True] * (len(embedding_set) + 1)))
    all_column_info = {}
    for meta in meta_data:
        if meta["name"] in drop:
            continue
        if meta["name"] == "판매량":
            tmp = data[meta["name"]]
            y_min, y_max = meta["info"]["min"], meta["info"]["max"]
            y_val = torch.Tensor(tmp).view(-1, 1)
        elif meta["name"] == "취급액":
            tmp = data[meta["name"]]
            revenue = torch.Tensor(tmp).view(-1, 1).to(device)
        elif meta["type"] in ["numerical", "numerical_minmax"]:
            tmp = data[meta["name"]]
            x_val.append(torch.Tensor(tmp).view(-1, 1))
            total_input_size += 1
            all_column_info[meta["name"]] = list(range(x_val_pos, x_val_pos + 1)) ; x_val_pos += 1
        elif meta["type"] == "category_onehot":
            tmp = data[meta["name"]].astype(int).values
            tmp = np.eye(len(meta['item']), dtype=int)[tmp, 1:]
            x_val.append(torch.Tensor(tmp))
            total_input_size += len(meta['item']) - 1
            all_column_info[meta["name"]] = list(range(x_val_pos, x_val_pos + len(meta['item']) - 1)); x_val_pos += len(meta['item']) - 1
        elif meta["type"] == "numerical_embedding":
            tmp = data[meta["name"]]
            x_embedding[meta["name"]] = {"model_basic": nn.Linear(1,meta['embedding_size'], bias=False).to(device),
                                         "data": torch.Tensor(tmp).view(-1, 1).to(device)}
            if _check_set(meta["name"],embedding_set) == "concat" or check[_check_set(meta["name"],embedding_set)] == True or concat:
                total_input_size += meta['embedding_size']
                check[_check_set(meta["name"], embedding_set)] = False

        elif meta["type"] == "category_embedding":
            tmp = data[meta["name"]].astype(int).values
            tmp = np.eye(len(meta['item']), dtype=int)[tmp, 1:]
            x_embedding[meta["name"]] = {"model_basic": nn.Linear(len(meta['item']) - 1, meta['embedding_size'], bias=False).to(device),
                                         "data": torch.Tensor(tmp).to(device)}
            if _check_set(meta["name"],embedding_set) == "concat" or check[_check_set(meta["name"], embedding_set)] == True or concat:
                total_input_size += meta['embedding_size']
                check[_check_set(meta["name"], embedding_set)] = False

    print("total_input_size:", total_input_size)
    if len(x_val) != 0:
        x_val = torch.cat(x_val, axis=1)
    if time_series == False:
        return (all_column_info, total_input_size, x_embedding, x_val, y_val, y_min, y_max, revenue)

    start_date, date_id, zero_pad, broad_id = \
        torch.tensor(data["start_date"]), torch.tensor(data["date_split"]), torch.tensor(data["zero_pad"]), torch.tensor(data["방송_id"])
    return (all_column_info, total_input_size, x_embedding, x_val, y_val, y_min, y_max, revenue,
            start_date, date_id, zero_pad, broad_id)

def _check_set(name, embedding_set):
    for set_name in embedding_set:
        if name in embedding_set[set_name]:
            return set_name
    return "concat"

def _check_category_set(info, embedding_set, concat):
    if concat:
        return
    for set_name in embedding_set:
        tmp = []
        for name in embedding_set[set_name]:
            if "embedding" not in info[name][0]:
                raise Exception("embedding_set이 잘못 지정돼 있습니다.")
            else:
                tmp.append(info[name][1])
        if len(set(tmp)) != 1:
            raise Exception("embedding_set이 잘못 지정돼 있습니다.")


