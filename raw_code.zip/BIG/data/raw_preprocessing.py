stan_Seqs = [50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 99][::-1]
stan_Days = [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 99][::-1]
import pandas as pd
import numpy as np
import datetime

for stan_Seq in stan_Seqs:
    for stan_Day in stan_Days:
        print(stan_Seq, stan_Day)
        data_loc = "/home/ljh5694/tmp/data/raw_data/total_feature_8월28.csv"
        zero_padding_period = 20 # 사이에 0을 넣는 간격(분)
        seq_stan = 20 # 연속방송 판단 기준

        cols = ["방송일시", "노출(분)", "마더코드", "상품코드", "상품명", "상품군", "판매단가", "취급액", "브랜드",
                "월별소비액", "지역", "기온", "강수량","vs","lcsch","dc10tca","dsnw","icsr","ss","pa","pv","hm",
                "ws","morning_drama", "popular_program", "holiday", "광고 사람"]

        data = pd.read_csv(data_loc,index_col = 0)[cols]
        data["방송일시"] = pd.to_datetime(data["방송일시"])

        ## data_split, start_date, zero_pad, 방송_id

        # 하루의 시작 만들기
        tmp = data[["방송일시","노출(분)"]][data["노출(분)"].notna()]
        tmp = tmp[tmp["방송일시"].apply(lambda x: x.hour) >= 3 ]
        start_of_date = tmp[~tmp["방송일시"].apply(lambda x: x.date()).duplicated()]["방송일시"]
        data.loc[start_of_date.index,"start_date"] = True

        G_num = -1
        def change(x):
            global G_num
            if x == True:
                G_num += 1
            return G_num

        data["date_split"] = data["start_date"].apply(change)
        data["start_date"] = data["start_date"].fillna(False).astype(int)

        # 일정 분 간격 이상이 났을때 패딩하기
        tmp = data[["방송일시","노출(분)", "start_date"]]
        tmp = tmp[tmp["노출(분)"].notna()]
        tmp["노출(분)"] = tmp["노출(분)"].apply(lambda x: datetime.timedelta(minutes = int(x)))
        tmp["끝"] = (tmp["방송일시"]+tmp["노출(분)"]).shift(1)
        tmp["간격"] = tmp["방송일시"] - tmp["끝"]
        tmp = tmp[tmp["방송일시"] > tmp["끝"]]
        tmp["zero_pad"] = tmp["간격"].apply(lambda x: x.total_seconds()) // (zero_padding_period * 60)
        tmp = tmp[tmp["zero_pad"] != 0]
        data = pd.merge(data, tmp[["방송일시","zero_pad"]],how = "left",on=["방송일시"])
        data["zero_pad"] = data["zero_pad"].fillna(0).astype(int)
        data.loc[data["노출(분)"].isna(),"zero_pad"] = 0

        # 같은 시간대 방송되는 동일 제품 0~ 로 구분하기
        tmp = pd.Series(data["방송일시"].unique()).to_frame()
        tmp = tmp.rename(columns = { 0 :"방송일시"})
        tmp["방송_id"] = range(len(tmp))
        data = pd.merge(data, tmp ,how = "left")

        ## 월, 시간, 요일, 연달아 쉬는날

        data["월"]  = data["방송일시"].apply(lambda x: x.month)

        data["시간"] = data["방송일시"].apply(lambda x: x.hour)

        day = dict(zip(range(7), ["월","화","수","목","금","토","일"]))
        data["방송요일"] = data["방송일시"].apply(lambda x: day[x.weekday()])

        # 연달아 쉬는날
        tmp_main = data[data["방송요일"].isin(["토", "일"]) | data["holiday"].isin(['Public Holiday', 'National holiday', 'Bank Holiday'])]["방송일시"]
        tmp_main = tmp_main.apply(lambda x: x.date())

        tmp = tmp_main.value_counts().sort_index().reset_index()["index"]
        max_index = len(tmp) - 1
        start_date = True
        i = 1
        j = 0
        def change(x):
            global start_date, i, j
            if start_date:
                num, value = x[0], x[1]
                while num + i <= max_index and value + datetime.timedelta(days=i) == tmp[num+i]:
                    i += 1
                    start_date = False
                j = i
                return j
            else:
                i -= 1
                if i == 1:
                    start_date = True
                return j

        tmp.reset_index().apply(change,axis=1)

        tmp = pd.concat([tmp,tmp.reset_index().apply(change,axis=1)] ,axis = 1).set_index("index")
        tmp_main = tmp_main.reset_index().set_index("방송일시")
        tmp_main["연속 휴일"] = tmp
        data["연속 휴일"] = tmp_main.set_index("index")
        data["연속 휴일"] = data["연속 휴일"].fillna(0).astype(int)

        ## 판매량

        data["판매량"] = data["취급액"] / data["판매단가"]

        ## 노출(분)\_all
        tmp = None
        def change(x):
            global tmp
            if str(x) == "nan":
                return tmp
            else:
                tmp = x
                return tmp
        data["노출(분)_all"] = data["노출(분)"].apply(change)


        # 연달아 나올때
        before = []
        before_time = None
        num = 1


        def change(val):
            time, reveal, x = val
            global before, num, before_time
            #     print(before,x)
            per = (np.isin(np.array(list(x)), np.array(list(before))))
            #     print(per.mean())
            if per.mean() > stan_Seq * 0.01 and before_time != None and \
                    before_time + datetime.timedelta(minutes=reveal) >= time:
                num += 1
            else:
                num = 1
            before = x
            before_time = time
            return num


        tmp = data.groupby(["방송일시", "노출(분)_all"])["상품명"].apply(lambda x: set(" ".join(x).split())).reset_index()
        tmp["index"] = tmp["방송일시"]
        tmp = tmp.set_index("방송일시")[["index", "노출(분)_all", "상품명"]]
        tmp = tmp.apply(change, axis=1)
        tmp.name = "Seq 방송 개수"
        data = pd.merge(data, tmp.reset_index(), on=["방송일시"])

        ## 하루동안 동일 상품개수 몇개 방송했는지

        tmp = data.groupby(["방송일시"])["상품명"].apply(lambda x: set(" ".join(x).split())).reset_index()
        tmp["방송일시_date"] = tmp["방송일시"].apply(lambda x: x.date())
        tmp["하루방송 수"] = None
        def cal_sim(x,ref):
            sim = (np.isin(np.array(list(x)), np.array(list(ref)))).mean()
            return sim
        def change(val):
            global tmp
            x, date, target = val
            if target != None:
                return
            tmp_data = tmp[tmp["방송일시_date"] == date]
            index = tmp_data[tmp_data["상품명"].apply(cal_sim, ref = x) > stan_Day * 0.01].index
            num = 1
            tmp.loc[index, "하루방송 수"] = list(range(1, len(index) + 1))
        tmp[["상품명","방송일시_date","하루방송 수"]].apply(change, axis = 1)
        data = pd.merge(data,tmp[["하루방송 수","방송일시"]],on=["방송일시"])

        ## 동시방송 상품개수

        data = pd.merge(data,data.groupby(["방송일시"]).size().reset_index(),on=["방송일시"]).rename(columns = {0:"동시방송 상품개수"})

        ## 성별, 국내생산, 일시불/무이자

        # 성별
        data.loc[data["상품명"].str.contains("남성") | data["상품명"].str.contains("남자"),"성별"] = "남성"
        data.loc[data["상품명"].str.contains("여성") | data["상품명"].str.contains("여자") ,"성별"] = "여성"

        # 무이자, 일시불
        data.loc[data["상품명"].str.contains("일시불"),"일시불/무이자"] = "일시불"
        data.loc[data["상품명"].str.contains("무이자"),"일시불/무이자"] = "무이자"

        #   국내제조, 국내산, 국내제작, 국내산, 국내생산 포함 여부
        data["광고 사람"] = data["광고 사람"].isin(["팽현숙", "이봉원", "숀리"]).astype(int)
        data.loc[data["상품명"].str.contains("국내"),"국내생산"] = "국내"
        data["국내생산"] = (data["지역"].notna() | data["국내생산"].notna()).astype(int)

        ## 월별소비액

        data["월별소비액"] = data["월별소비액"].astype(int) - 1

        ## 저장

        total_col = ['월', '시간', '연속 휴일', '방송요일', '노출(분)_all', '마더코드', '상품코드', '상품군', '브랜드',
                     '판매단가', '월별소비액', '광고 사람', '국내생산', '기온', '강수량', 'vs', 'lcsch', 'dc10tca',
                     'icsr', 'ss', 'pa', 'pv', 'hm', 'ws', 'morning_drama','popular_program', '동시방송 상품개수',
                     'Seq 방송 개수', "하루방송 수", '성별', '일시불/무이자', '판매량', '취급액', 'start_date',
                     'date_split','zero_pad', '방송_id']
        data = data[total_col]
        data.to_csv("/home/ljh5694/tmp/data/origin_data/total_feature_"+ str(stan_Seq) + "_" + str(stan_Day) +".csv")